//
//  SEL4C_IOSApp.swift
//  SEL4C_IOS
//
//  Created by Ivan Santiago Méndez on 21/08/23.
//

import SwiftUI

@main
struct SEL4C_IOSApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
    
}
